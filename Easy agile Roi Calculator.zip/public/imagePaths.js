export const IMAGES = {
  EaCalculator: "../img/EA_calculator_graphic.svg",
  EaLogoHorizontalBlack: "../img/EA_Logo_Horizontal_RGB_Black.svg",
  EaLogoHorizontalViolet: "../img/EA_Logo_Horizontal_RGB_Deep_Violet.svg",
  EaLogoHorizontalWhite: "../img/EA_Logo_Horizontal_RGB_White.svg",
  EaLogoBlack: "../img/EA_Logo_Stacked_RGB_Black.svg",
  EaLogoViolet: "../img/EA_Logo_Stacked_RGB_Deep_Violet.svg",
  EaLogoWhite: "../img/EA_Logo_Stacked_RGB_White.svg",
  ProgramsIcon: "../img/Programs_Icon.svg",
  RoadmapsIcon: "../img/Roadmaps_Icon.svg",
  TeamRhythmIcon: "../img/TeamRhythm_Icon.svg",
}

