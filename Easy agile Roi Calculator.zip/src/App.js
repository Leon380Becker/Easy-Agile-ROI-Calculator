import React, { useState, useRef, useEffect } from "react";
import { Box } from "@mui/material";
import { ThemeProvider } from "@mui/material/styles";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { theme } from "./theme";
import { CalculatorBox, DisplayBox } from "./components/index.js";
import { REGION } from "./constants/index.js";


export default function App() {
  const displayBoxRef = useRef(null)

  const [state, setState] = useState({
    location: REGION.N_AMERICA,
    employeeNumIndex: 0,
    engineerNum: 1,
    teamsNum: 1,
    sprintPlanningFreq: 1,
  });

  const [graphImage, setGraphImage] = useState(null);

  useEffect(() => {
    console.log("State:", state); // Check the state values for debugging
  }, [state]);

  const getChartImage = () => {
    return displayBoxRef.current.getChartImage()
  }

  return (
    <ThemeProvider theme={theme}>
      <Router>
        <Routes>
          {/* ROI Calculator */}
          <Route
            path="/"
            element={
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  height: "100vh",
                  width: "100%",
                  margin: "0 auto",
                  overflowX: "hidden",
                }}
              >
                <CalculatorBox state={state} setState={setState} getChartImage={getChartImage} />
                <Box sx={{ flex: 1, backgroundColor: "#E5d7ff" }}>
                  <DisplayBox ref={displayBoxRef} state={state} graphImage={graphImage} setGraphImage={setGraphImage} />
                </Box>
              </Box>
            }
          />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}
