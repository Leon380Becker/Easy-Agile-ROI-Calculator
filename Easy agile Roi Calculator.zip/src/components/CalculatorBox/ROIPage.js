import React, { useState } from "react";
import { CalculatorForm } from "./CalculatorForm";
import { ROISummary } from "./ROISummary";

export function ROIPage() {
  // Shared state
  const [state, setState] = useState({
    location: "",
    employeeNumIndex: 0,
    engineerNum: 1,
    teamsNum: 1,
    sprintPlanningFreq: 1,
  });

  return (
    <div style={{ display: "flex", gap: 20 }}>
      {/* Pass state & updater function to CalculatorForm */}
      <CalculatorForm state={state} setState={setState} />
      
      {/* Pass state to ROISummary */}
      <ROISummary state={state} />
    </div>
  );
}
