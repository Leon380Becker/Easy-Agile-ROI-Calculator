import { Box, Button, Input, Stack, Typography } from "@mui/material";
import { X } from "lucide-react";
import { useState, useEffect } from "react";
import { generatePdf } from "../../../pdf/generate-pdf.js";

const IMAGES = {
  EA_Logo_Violet: "/assets/EA_Logo_Horizontal_RGB_Deep_Violet.svg",
};

const ROIPopup = ({ isOpen, onClose, state, getChartImage }) => {
  const [formData, setFormData] = useState({ name: "", email: "" });
  const [errors, setErrors] = useState({ name: false, email: false });
  const [pending, setPending] = useState(false);
  const [success, setSuccess] = useState(false);

  // Reset form and success state whenever the popup opens
  useEffect(() => {
    if (isOpen) {
      setSuccess(false);
      setFormData({ name: "", email: "" });
      setErrors({ name: false, email: false });
    }
  }, [isOpen]); // Runs when `isOpen` changes

  if (!isOpen) return null;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: false });
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = {
      name: !formData.name,
      email: !validateEmail(formData.email),
    };
    setErrors(newErrors);
    if (newErrors.name || newErrors.email) return;

    setPending(true);

    try {
      const chartImage = getChartImage();
      const blob = await generatePdf(state, formData.name, chartImage);

      const formDataToSend = new FormData();
      formDataToSend.append("name", formData.name);
      formDataToSend.append("email", formData.email);
      formDataToSend.append("pdf", blob, "roi.pdf");

      const res = await fetch("http://localhost:5000/submit", {
        method: "POST",
        body: formDataToSend,
      });

      if (res.ok) {
        setSuccess(true);
        setTimeout(() => {
          setSuccess(false); // Reset the success message after a delay
        }, 3000);
      } else {
        const errorResponse = await res.json();
        console.error("Error response from server:", errorResponse);
        alert("There was an error submitting the form.");
      }
    } catch (err) {
      console.error("Submit error:", err);
      alert("Something went wrong.");
    } finally {
      setPending(false);
    }
  };

  return (
    <Box
      sx={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        zIndex: 1000,
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Box
        sx={{
          position: "relative",
          width: "100%",
          maxWidth: "440px",
          mx: "auto",
          background: "linear-gradient(135deg, #fdfdfd 20%, #f7f3f8 50%, #e9e7ee 90%)",
          borderRadius: 4,
          boxShadow: 6,
          p: { xs: 3, md: 5 },
          fontFamily: '"Inter", sans-serif',
        }}
      >
        {/* Close Button */}
        <Button
          onClick={onClose}
          sx={{
            position: "absolute",
            top: 16,
            right: 16,
            minWidth: "auto",
            color: "grey.600",
            zIndex: 10,
          }}
        >
          <X size={24} />
        </Button>

        {/* Logo */}
        <Box sx={{ textAlign: "center", mb: 2 }}>
          <img
            src={IMAGES.EA_Logo_Violet}
            alt="EA Logo"
            style={{ maxWidth: "160px", height: "auto" }}
          />
        </Box>

        {/* Sent Message or Form */}
        {success ? (
          <Box sx={{ textAlign: "center", my: 3 }}>
            <Typography variant="h6" sx={{ color: "#4CAF50", fontWeight: 600 }}>
              Sent to {formData.email}
            </Typography>
            <Typography variant="body2" sx={{ color: "text.secondary", mt: 1 }}>
              Your report has been successfully sent. ✅
            </Typography>
          </Box>
        ) : (
          <>
            {/* Description */}
            <Typography
              variant="body2"
              sx={{ textAlign: "center", color: "text.secondary", mb: 4 }}
            >
              Your ROI report will be sent to your email.
            </Typography>

            {/* Form */}
            <Stack spacing={3} sx={{ maxWidth: 400, mx: "auto" }}>
              <Box>
                <Typography sx={{ fontWeight: 500, mb: 1 }}>
                  First Name <span style={{ color: "red" }}>*</span>
                </Typography>
                <Input
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  fullWidth
                  disableUnderline
                  sx={{
                    borderBottom: `2px solid ${errors.name ? "red" : "#ccc"}`,
                    px: 0,
                    py: 1,
                    fontSize: "1rem",
                  }}
                />
                {errors.name && (
                  <Typography color="error" variant="caption">
                    Please complete this required field
                  </Typography>
                )}
              </Box>

              <Box>
                <Typography sx={{ fontWeight: 500, mb: 1 }}>
                  Email <span style={{ color: "red" }}>*</span>
                </Typography>
                <Input
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  fullWidth
                  type="email"
                  disableUnderline
                  sx={{
                    borderBottom: `2px solid ${errors.email ? "red" : "#ccc"}`,
                    px: 0,
                    py: 1,
                    fontSize: "1rem",
                  }}
                />
                {errors.email && (
                  <Typography color="error" variant="caption">
                    {formData.email
                      ? "Please enter a valid email address"
                      : "Please complete this required field"}
                  </Typography>
                )}
              </Box>

              {/* Submit Button */}
              <Button
                variant="contained"
                disabled={pending}
                onClick={handleSubmit}
                sx={{
                  mt: 4,
                  py: 1.5,
                  fontSize: "1rem",
                  borderRadius: "8px",
                  backgroundColor: pending ? "grey" : "#7B2CBF",
                  width: "100%",
                  "&:hover": {
                    backgroundColor: "#6822ad",
                  },
                }}
              >
                {pending ? "Sending..." : "Download Report"}
              </Button>
            </Stack>
          </>
        )}
      </Box>
    </Box>
  );
};

export default ROIPopup;
