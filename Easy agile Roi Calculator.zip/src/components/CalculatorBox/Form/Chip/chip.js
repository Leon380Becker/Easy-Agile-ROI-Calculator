import React from "react";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";

export function BasicChips({ label = "Default Chip", onClick }) {
  return (
    <Stack direction="row" spacing={1} sx={{ mt: 2 }}> 
      <Chip 
        label={label} 
        onClick={onClick} 
        sx={{
          backgroundColor: "#2D005D", 
          color: "white", 
          fontSize: "0.9em",
          padding: "22px 30px",
          borderRadius: "120px",
          cursor: "pointer", 
          "&:hover": {
            backgroundColor: "#402758",
          }
        }} 
      />
    </Stack>

  );
}

