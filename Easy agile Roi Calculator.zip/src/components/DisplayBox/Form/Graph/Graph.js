import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

// Register necessary Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

/**
 * Graph component renders a responsive line chart showing:
 * - ROI over 36 months
 * - Annual average ROI per year (scaled line)
 * 
 * Props:
 * - cumulativeOutputArray: ROI values for 36 months
 * - annualAvgYearOne/Two/Three: Yearly average ROI values
 * - containerWidth/containerHeight: Optional dimensions
 * - labelFontSize: Axis font size (customizable, e.g. for PDF rendering)
 * 
 * Added functionality:
 * - Allows exporting the graph as a high-resolution image for PDF generation.
 */
export const Graph = forwardRef(
  (
    {
      cumulativeOutputArray,
      annualAvgYearOne,
      annualAvgYearTwo,
      annualAvgYearThree,
      containerWidth = "100%",
      containerHeight = "100%",
      labelFontSize = 12,
    },
    ref
  ) => {
    const chartRef = useRef(null);
    const [graphHeight, setGraphHeight] = useState(300); // Default: mobile
    
    // Dynamically update chart height based on screen size
    const updateGraphHeight = () => {
      const screenWidth = window.innerWidth;
      if (screenWidth >= 1024) setGraphHeight(500); // Desktop
      else if (screenWidth >= 768) setGraphHeight(400); // Tablet
      else setGraphHeight(300); // Mobile
    };

    useEffect(() => {
      updateGraphHeight();
      window.addEventListener("resize", updateGraphHeight);
      return () => window.removeEventListener("resize", updateGraphHeight);
    }, []);

    // Utilities to sanitize inputs
    const safeNumber = (val) => (isFinite(val) && !isNaN(val) ? val : 0);

    const safeArray = (arr) =>
      Array.isArray(arr) && arr.length >= 36
        ? arr.map((val) => (isFinite(val) ? val : 0))
        : new Array(36).fill(0);

    const dataPoints = safeArray(cumulativeOutputArray);
    const avgOne = safeNumber(annualAvgYearOne);
    const avgTwo = safeNumber(annualAvgYearTwo);
    const avgThree = safeNumber(annualAvgYearThree);

    // Scale the red line to match ROI (blue line) max value
    const maxBlue = Math.max(...dataPoints);
    const maxRed = Math.max(avgOne, avgTwo, avgThree);
    const scalingFactor = maxBlue > 0 && maxRed > 0 ? maxBlue / maxRed : 1;

    // Repeat each annual average value over 12 months
    const annualAvgData = [
      0, // Start at 0
      ...new Array(12).fill(avgOne * scalingFactor),
      ...new Array(12).fill(avgTwo * scalingFactor),
      ...new Array(12).fill(avgThree * scalingFactor),
    ];

    // Label only key points on X-axis
    const xLabels = Array.from({ length: 37 }, (_, i) => {
      if (i === 12) return "Year one";
      if (i === 24) return "Year two";
      if (i === 36) return "Year three";
      return "";
    });

    // Chart.js dataset config
    const data = {
      labels: xLabels,
      datasets: [
        {
          label: "ROI",
          data: [0, ...dataPoints],
          borderColor: "#5F0BFF",
          borderWidth: 4,
          tension: 0.4,
          pointRadius: 0,
          pointHoverRadius: 0,
          fill: false,
          borderCapStyle: "butt",
        },
        {
          label: "",
          data: annualAvgData,
          borderColor: "red",
          borderWidth: 2,
          tension: 0.4,
          pointRadius: 0,
          pointHoverRadius: 0,
          fill: false,
          borderCapStyle: "butt",
        },
      ],
    };

    // Chart.js appearance & behavior config
    const options = {
      responsive: true,
      maintainAspectRatio: false,
      devicePixelRatio: window.devicePixelRatio || 10,
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            maxRotation: 90,
            minRotation: 90,
            font: { weight: "bold", size: labelFontSize },
            autoSkip: false,
          },
        },
        y: {
          beginAtZero: true,
          ticks: {
            font: { weight: "bold", size: labelFontSize },
            callback: (value) => {
              if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}m`;
              if (value >= 1000) return `$${(value / 1000).toFixed(0)}k`;
              return "0";
            },
          },
        },
      },
      plugins: {
        tooltip: { enabled: true },
        legend: { display: false },
      },
    };

    // Expose method to get chart as an image for PDF export
    useImperativeHandle(ref, () => ({
      getChartImage: () => {
        const chart = chartRef.current;
        if (!chart) return null;
    
        const originalRatio = chart.options.devicePixelRatio;
        chart.options.devicePixelRatio = 5.0; // Boost quality
    
        chart.update('none'); // Re-render with new ratio
        const image = chart.toBase64Image("image/png", 5.0);
    
        chart.options.devicePixelRatio = originalRatio; // Reset back
        chart.update('none'); // Re-render with default ratio
    
        return image;
      },
    }));
    

    return (
      <div
        style={{
          width: "100%",
          height: `${graphHeight}px`,
          maxHeight: containerHeight,
          overflow: "hidden",
        }}
      >
        <Line ref={chartRef} data={data} options={options} />
      </div>
    );
  }
);
