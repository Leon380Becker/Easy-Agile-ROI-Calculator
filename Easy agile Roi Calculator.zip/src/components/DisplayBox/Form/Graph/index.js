import React, { forwardRef } from "react";
import { Graph } from "./Graph.js";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

/**
 * GraphCard component renders a styled card containing:
 * - A responsive graph
 * - ROI legend labels below the chart
 * 
 * Props:
 * - annualAvgYearOne, annualAvgYearTwo, annualAvgYearThree: Annual average ROI values
 * - cumulativeOutputArray: Array of cumulative ROI values to plot over time
 */
export const GraphCard = forwardRef(({
  annualAvgYearOne,
  annualAvgYearTwo,
  annualAvgYearThree,
  cumulativeOutputArray,
  graphImage,
  setGraphImage
}, ref) => {
  // Reusable function for legend labels
  const LegendItem = ({ color, label }) => (
    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
      <Box
        sx={{
          width: 25,
          height: 5,
          backgroundColor: color,
          borderRadius: "4px",
        }}
      />
      <Typography fontWeight="bold" fontSize="0.9rem">
        {label}
      </Typography>
    </Box>
  );

  return (
    <Box
      sx={{
        width: "100%",
        minHeight: "450px",
        padding: { xs: "2vw", sm: "24px" },
        margin: { xs: "1vw", sm: "auto" },
        paddingTop: { xs: "20%", sm: "10%" },
        borderRadius: "20px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        boxShadow: "6px 6px 40px rgba(0, 0, 0, 0.05)",
        backgroundColor: "white",
        boxSizing: "border-box",
      }}
    >
      {/* Graph visualization section */}
      <Box sx={{ width: "100%", paddingLeft: 0, margin: 0 }}>
        <Graph
          ref={ref}
          annualAvgYearOne={annualAvgYearOne}
          annualAvgYearTwo={annualAvgYearTwo}
          annualAvgYearThree={annualAvgYearThree}
          cumulativeOutputArray={cumulativeOutputArray}
          graphImage={graphImage}
          setGraphImage={setGraphImage}
        />
      </Box>


      {/* Legend labels below the graph */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 2,
          paddingTop: "4%",
          paddingBottom: "8%",
        }}
      >
        <LegendItem color="#5F0BFF" label="ROI" />
        <LegendItem color="red" label="Annual Average ROI" />
      </Box>
    </Box>
  );
}
)