// components/PDFPreview.jsx
import React from "react";
import { PDFViewer } from "@react-pdf/renderer";
import PDFDocument from "./PDFDocument";

export default function PDFPreview({ userName, state }) {
  return (
    <PDFViewer style={{ width: "100%", height: "100vh" }}>
      <PDFDocument name={userName} 
       GraphImage={state.GraphImage}
       delaysPerYear={state.delaysPerYear}
       teamsImpacted={state.teamsImpacted}
       avgDelayDuration={state.avgDelayDuration}
       annualCostOfSprintsPerTeam={state.annualCostOfSprintsPerTeam}
       annualCostOfSprintsPerOrganisation={state.annualCostOfSprintsPerOrganisation}
       annualCostOfDelays={state.annualCostOfDelays}
       annualCostRetroPerTeam={state.annualCostRetroPerTeam}
       annualCostRetroPerOrg={state.annualCostRetroPerOrg}
       costOfEatr={state.costOfEatr}
       costOfEapro={state.costOfEapro}
       costOfEaroa={state.costOfEaroa}
       bundleCost={state.bundleCost}
       retroImprovement={state.retroImprovement}
       sprintPredictability={state.sprintPredictability}
       sprintEfficiency={state.sprintEfficiency}
       yearOneCmlPct={state.yearOneCmlPct}
       yearTwoCmlPct={state.yearTwoCmlPct}
       yearThreeCmlPct={state.yearThreeCmlPct}
       productivityGain={state.productivityGain}
       cumulativeOutputArray={state.cumulativeOutputArray}
       annualAvgYearOne={state.annualAvgYearOne}
       annualAvgYearTwo={state.annualAvgYearTwo}
       annualAvgYearThree={state.annualAvgYearThree}
      />
    </PDFViewer>
  );
}
