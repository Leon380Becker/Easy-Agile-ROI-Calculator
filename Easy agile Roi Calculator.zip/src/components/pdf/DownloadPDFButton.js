import React from "react";
import { pdf } from "@react-pdf/renderer";
import PDFDocument from "./PDFDocument";
import { saveAs } from "file-saver";


const DownloadPDFButton = ({state}) => {
  const handleDownload = async () => {
    const {
      employeeKeys,
      employeeNum,
      avgTeamSize,
      delaysPerYear,
      teamsImpacted,
      avgDelayDuration,
      annualCostOfSprintsPerTeam,
      annualCostOfSprintsPerOrganisation,
      annualCostOfDelays,
      annualCostRetroPerTeam,
      annualCostRetroPerOrg,
      costOfEatr,
      costOfEapro,
      costOfEaroa,
      bundleCost,
      retroImprovement,
      sprintPredictability,
      sprintEfficiency,
      yearOneCmlPct,
      yearTwoCmlPct,
      yearThreeCmlPct,
      cumulativeOutputArray,
      annualAvgYearOne,
      annualAvgYearTwo,
      annualAvgYearThree,
      productivityGain,
    } = calculateAll(state)

  
    const blob = await pdf(<PDFDocument {...props} />).toBlob();
    saveAs(blob, "Easy_Agile_Report.pdf");
  };

  return (
    <button onClick={handleDownload}>
      Download PDF
    </button>
  );
};

export default DownloadPDFButton;
