const express = require("express");
const puppeteer = require("puppeteer");
const cors = require("cors");

const app = express();
const port = 5000;

// Enable CORS to allow frontend to access the backend
app.use(cors());

// Route to generate PDF
app.get("/generate-pdf", async (req, res) => {
  const browser = await puppeteer.launch({ headless: "new" });
  const page = await browser.newPage();

  // Open your React app's local URL
  await page.goto("http://localhost:3000/pdf-report", { waitUntil: "networkidle2" });

  // Generate a PDF from the page
  const pdfBuffer = await page.pdf({ format: "A4", printBackground: true });

  // Send the PDF as a response
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", 'attachment; filename="Generated_Report.pdf"');
  res.send(pdfBuffer);

  await browser.close();
});

// Start the server
app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
